# Guia de publicação — GitHub + Cloudflare Pages
O site é estático: **sem comando de build**.

1. **GitHub:** crie um repositório vazio. Na pasta do site: `git init` → `git add .` → `git commit -m "Site inicial"` → `git branch -M main` → `git remote add origin URL-DO-REPOSITORIO` → `git push -u origin main`.
2. **Cloudflare:** Workers & Pages → Create → Pages → Connect to Git → escolha o repositório. Framework: None · Build command: *(vazio)* · Output directory: `/`. Confirme os nomes dos campos na tela, pois a interface da Cloudflare muda.
3. **Domínio próprio:** no projeto → Custom domains. **Antes de trocar nameservers, copie todos os registros DNS atuais (principalmente e-mail MX/TXT).** HTTPS é automático (pode levar alguns minutos).
4. **Depois do domínio:** informe o endereço final para adicionar `canonical`, `sitemap.xml` e `og:url`.
